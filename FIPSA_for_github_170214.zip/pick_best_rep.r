args <- commandArgs()

K_set <- as.numeric(args[length(args)-2])
cwd <- args[length(args)-1]
max_rep <- as.numeric(args[length(args)])
cat("max_rep:\t", max_rep, '\n')

setwd(cwd)

G_max <- double()
for(rep in 1:max_rep) {
	fgroup <- sprintf("inp_ped_test_1KG_P3.K_%d.rep%d.out", K_set, rep)
	d <- read.table(fgroup, nrows = 1)
	G_max[rep] <- d[1,2]
}
rank <- cbind(1:max_rep, G_max)
rank <- rank[order(rank[,2], decreasing = T), ]
fbest <- sprintf("inp_ped_test_1KG_P3.K_%d.rep%d.out", K_set, rank[1,1])
d <- read.table(file = fbest)
write.table(d, file = sprintf("inp_ped_test_1KG_P3.K_%d.best.grouping.out", K_set), quote = F, col.names = F, row.names = F)
d2 <- d
cat("best rep:", '\t', rank[1,1], '\n')
cat("test passed!\n")


