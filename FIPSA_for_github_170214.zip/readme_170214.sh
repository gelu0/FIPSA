#!/bin/bash

cwd=`pwd`

cd $cwd

#### first step: get the grouping 
## input parameters
# -K: number of subpopulations. # please specify the desired number of subpopulations in -K parameter. For your dataset, we suggest -K 5
# -i: input vcf	# if input is vcf format use, then use -i, and do not use -a 
# -a: input ped # Now we also support ped as input. Note that both -a (ped file) and -b (corresponding map file) should be specified. Do not use -i if input is in ped format
# -b: input map # the corresponding map file of the ped file. Should be used together with -a
# -o: output grouping

# We run multiple replicates for the same K, each replicate can be put on one core.
# For the test dataset, one replicate takes less than one minute. If we run 20 replicates on 20 cores, respectively, then we get 20 results within one minute.
ped=$cwd/inp_test_1KG_P3.ped	# test ped file
map=$cwd/inp_test_1KG_P3.map	# test map file
# Here, we run all 5 replicates on the same core. To save time, we could put each replicate on one core.
max_rep=2
K=6
for rep in `seq 1 1 ${max_rep}`
do
	$cwd/Taichi_161024_Ubuntu -K ${K} -a $ped -b $map -o $cwd/inp_ped_test_1KG_P3.K_${K}.rep${rep}.out
done

## Then we get five output files. The best grouping has the largest score which locates in the first row second column of each output file. Here, the best score is more than 195600.

#### second step, pick the best grouping
# Here we provide a simple r code to pick the best grouping out of all replicates
Rscript $cwd/pick_best_rep.r --args "${K}" "$cwd" "$max_rep"
# the best grouping here is "inp_ped_test_1KG_P3.K_5.best.grouping.out"

## Format of the output
# The first column is the individual id. The second column is the grouping index. If we specified K subpopulations, then the grouping index should be 0,1,...,K-1.
# for example 
#34838/42339 195605.59375
#HG00096 1	# the individual "HG00096" belongs to group "1", so do "HG00097", "HG00099", "HG00100", "HG00101"
#HG00097 1
#HG00099 1
#HG00100 1
#HG00101 1


